# 🏠 Hostel Management System

A **mobile-friendly desktop application** built with Python & Tkinter for managing hostel students, rooms, mess charges, bills, and complaints — with a secure login system for Admin and Members.

---

## 📸 Screenshots

> _Login screen, Dashboard with navigation tiles, Hostel room grid, Mess menu, Complaints with solve dialog._

---

## ✨ Features

### 🔐 Authentication
- **Admin Login** — secure password-protected admin account
- **Member Registration** — new members sign up using the Admin ID code issued by the admin
- **Admin Settings** — change Admin ID code and password anytime; manage/remove members

### 📊 Dashboard
- Live stats: total students, bed occupancy, pending complaints, unpaid bills
- Large color-coded navigation tiles for quick access on mobile/touch screens

### 🏨 Hostel View
- Visual room grid showing each room's occupancy, capacity, and occupant names
- Color-coded: 🟢 Available / 🔴 Full

### 🍽️ Mess Menu
- Admin can add daily menu items with name, price, date, and a **photo**
- Members can browse the menu and tap **View Image** to see dish photos
- Admin can delete menu items

### 🧑‍🎓 Students
- Add students with full details: name, CNIC, contact, department, semester
- View all students with their assigned room at a glance

### 🛏️ Rooms
- Add rooms with custom number and bed capacity
- Assign students to rooms; prevents over-assignment
- Room status updates automatically (Available / Full)

### 🍽️ Mess Charges
- Record daily mess charges per student with date & day auto-fill
- **Other Activity** field for extra charges with description
- Live total calculator
- Toggle Paid/Unpaid status
- Attach and view receipt images (requires `pillow`)

### 💰 Monthly Bills
- Generate monthly bills: room + mess + other charges + activity charges
- Pull mess totals automatically from recorded charges
- Mark bills paid/unpaid
- Attach and view payment receipt images
- Detailed bill receipt dialog

### 📝 Complaints
- Students/members can file complaints with full text
- Admin can **Solve** complaints with a written solution or quick-resolve
- Admin can re-open resolved complaints
- **Submit / Clear / Skip** buttons on the form
- Solution text is shown on each resolved complaint card

---

## 🚀 Getting Started

### Prerequisites

- Python **3.9+**
- `pillow` _(optional — required for image preview)_

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/hostel-management-system.git
cd hostel-management-system

# 2. (Optional) Install Pillow for image support
pip install pillow

# 3. Run the app
python hostel_management_mobile.py
```

---

## 🔑 Default Login Credentials

| Role  | Username | Password   | Admin ID     |
|-------|----------|------------|--------------|
| Admin | `admin`  | `admin123` | `HOSTEL2024` |

> ⚠️ **Change the default password and Admin ID immediately after first login** via ⚙️ Admin Settings.

---

## 📁 Project Structure

```
hostel-management-system/
│
├── hostel_management_mobile.py   # Main application
├── hostel_data_mobile.json       # Auto-generated data file (gitignored)
├── receipts/                     # Attached receipt images (auto-created)
├── mess_images/                  # Mess menu photos (auto-created)
└── README.md
```

---

## 🛠️ Tech Stack

| Layer       | Technology                  |
|-------------|-----------------------------|
| Language    | Python 3.9+                 |
| GUI         | Tkinter + ttk               |
| Image View  | Pillow (PIL)                |
| Data Store  | JSON (local file)           |
| Security    | SHA-256 password hashing    |

---

## 📋 How to Use

### First-Time Setup (Admin)
1. Launch the app and log in as **Admin** (`admin` / `admin123`)
2. Go to ⚙️ **Admin Settings** and update the password and Admin ID
3. Share the new **Admin ID** with trusted members who need to register

### Adding a Member Account
1. On the login screen, click **Create Member Account**
2. Fill in name, username, password, and the **Admin ID** provided by admin
3. Sign in as Member

### Daily Workflow
1. **Add students** → **Add rooms** → **Assign students to rooms**
2. Add **mess charges** daily for each student
3. At month end, generate **monthly bills** (pulls mess totals automatically)
4. Attach **receipt images** for payments
5. Resolve **complaints** as they come in

---

## 🔒 Security Notes

- Passwords are hashed using **SHA-256** and never stored in plain text
- The Admin ID acts as a registration token — keep it private
- All data is stored locally in `hostel_data_mobile.json`

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

1. Fork the repo
2. Create your feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m 'Add my feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## 👤 Author

**Your Name**
- GitHub: [@YOUR_USERNAME](https://github.com/YOUR_USERNAME)

---

> Built with ❤️ using Python & Tkinter
